import React, { useEffect, useMemo, useState } from 'react';
import useEmblaCarousel from 'embla-carousel-react';
import SamsungCard from './SamsungCard';

// Set this to false to disable autoplay globally.
const ENABLE_AUTOPLAY = true;
const AUTOPLAY_INTERVAL = 4000;

// Adjust the card counts here for each screen size.
const SLIDER_LAYOUT = {
	mobile: 1,
	tablet: {
		category: 2,
		product: 2,
	},
	laptop: {
		category: 3,
		product: 2,
	},
	desktop: {
		category: 3,
		product: 3,
	},
};

const DESKTOP_BREAKPOINT = 992;
const LARGE_DESKTOP_BREAKPOINT = 1280;
const TABLET_BREAKPOINT = 768;

function getSlidesToShow(viewportWidth, variant) {
	if (viewportWidth >= LARGE_DESKTOP_BREAKPOINT) {
		return SLIDER_LAYOUT.desktop[variant];
	}

	if (viewportWidth >= DESKTOP_BREAKPOINT) {
		return SLIDER_LAYOUT.laptop[variant];
	}

	if (viewportWidth >= TABLET_BREAKPOINT) {
		return SLIDER_LAYOUT.tablet[variant];
	}

	return SLIDER_LAYOUT.mobile;
}

function SamsungProductSlider({ items, variant, onItemClick }) {
	const [activeIndex, setActiveIndex] = useState(0);
	const [viewportWidth, setViewportWidth] = useState(() =>
		typeof window === 'undefined' ? 1440 : window.innerWidth
	);

	const slidesVisible = getSlidesToShow(viewportWidth, variant);
	const canSlide = items.length > slidesVisible;
	const isDesktopViewport = viewportWidth >= DESKTOP_BREAKPOINT;
	const isTabletViewport = viewportWidth >= TABLET_BREAKPOINT;
	const emblaOptions = useMemo(
		() => ({
			align: isDesktopViewport ? 'start' : 'center',
			loop: false,
			dragFree: false,
			skipSnaps: false,
			containScroll: 'trimSnaps',
			watchDrag: canSlide,
		}),
		[canSlide, isDesktopViewport]
	);

	const [emblaRef, emblaApi] = useEmblaCarousel(emblaOptions);

	useEffect(() => {
		const handleResize = () => {
			setViewportWidth(window.innerWidth);
		};

		window.addEventListener('resize', handleResize);

		return () => {
			window.removeEventListener('resize', handleResize);
		};
	}, []);

	useEffect(() => {
		if (!emblaApi) {
			return undefined;
		}

		emblaApi.reInit();
		emblaApi.scrollTo(0, true);
		setActiveIndex(0);

		const onSelect = () => {
			setActiveIndex(emblaApi.selectedScrollSnap());
		};

		onSelect();
		emblaApi.on('select', onSelect);
		emblaApi.on('reInit', onSelect);

		return () => {
			emblaApi.off('select', onSelect);
			emblaApi.off('reInit', onSelect);
		};
	}, [emblaApi, items.length, slidesVisible, variant]);

	useEffect(() => {
		if (!ENABLE_AUTOPLAY || !canSlide || !isDesktopViewport || !emblaApi) {
			return undefined;
		}

		const autoplayTimer = window.setInterval(() => {
			if (emblaApi.canScrollNext()) {
				emblaApi.scrollNext();
			} else {
				emblaApi.scrollTo(0);
			}
		}, AUTOPLAY_INTERVAL);

		return () => {
			window.clearInterval(autoplayTimer);
		};
	}, [canSlide, emblaApi, isDesktopViewport]);

	const scrollSnaps = emblaApi?.scrollSnapList() ?? [];
	const showCategoryDots = variant === 'category' && canSlide && scrollSnaps.length > 1;

	const shellStyle = useMemo(
		() => ({
			'--slides-per-view': slidesVisible,
			'--slide-gap': isDesktopViewport ? '20px' : isTabletViewport ? '14px' : '0px',
			'--inactive-scale': isDesktopViewport ? 0.94 : isTabletViewport ? 0.97 : 0.985,
			'--active-scale': 1,
		}),
		[isDesktopViewport, isTabletViewport, slidesVisible]
	);

	return (
		<div className={`samsung-slider-shell samsung-slider-shell--${variant}`} style={shellStyle}>
			<div className="samsung-slider-shell__viewport" ref={emblaRef}>
				<div className="samsung-slider-shell__container">
					{items.map((item, index) => (
						<div key={item.id} className="samsung-slider-shell__slide">
							<div className={`samsung-slider-shell__scale ${activeIndex === index ? 'is-active' : ''}`}>
								<SamsungCard
									item={item}
									variant={variant}
									isActive={activeIndex === index}
									onClick={onItemClick}
								/>
							</div>
						</div>
					))}
				</div>
			</div>

			{showCategoryDots && (
				<div className="samsung-slider-shell__dots" aria-label="Slider navigation">
					{scrollSnaps.map((_, index) => (
						<button
							key={`dot-${index}`}
							type="button"
							className={`samsung-slider-shell__dot ${activeIndex === index ? 'is-active' : ''}`}
							aria-label={`Go to slide ${index + 1}`}
							onClick={() => emblaApi?.scrollTo(index)}
						/>
					))}
				</div>
			)}

			{canSlide && isDesktopViewport && (
				<div className="samsung-slider-shell__desktop-nav">
					<button
						type="button"
						className="samsung-slider-shell__nav-btn samsung-slider-shell__nav-btn--prev"
						onClick={() => emblaApi?.scrollPrev()}
					>
						Previous
					</button>
					<button
						type="button"
						className="samsung-slider-shell__nav-btn samsung-slider-shell__nav-btn--next"
						onClick={() => emblaApi?.scrollNext()}
					>
						Next
					</button>
				</div>
			)}
		</div>
	);
}

export default SamsungProductSlider;
