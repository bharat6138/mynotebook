# Samsung Rewards

Standalone React 18.2 JavaScript project for a Samsung-style enterprise rewards journey.

## Stack

- React 18.2
- Bootstrap 5
- Custom scoped CSS
- react-slick
- scroll-shadow-element

## Screens

- Migration choice
- Mobile login
- OTP verification
- Upgrade success
- Product category slider
- Recommended products slider
- Benefits QR screen

## Scripts

- `npm start`
- `npm run build`

## Notes

- Only `.js` files are used.
- Slider styling is fully customized in the scoped Samsung module CSS.
- Mobile and tablet layouts run full-screen; desktop applies a restrained web shell.
- Top bar intentionally shows only `Home`.
- Samsung-style local SVG assets are stored under `public/images/samsung-rewards`.
- The fixed header uses `scroll-shadow-element` for subtle scroll-aware visual separation.
- Current implementation is isolated inside the Samsung module and does not depend on any external project routes.
