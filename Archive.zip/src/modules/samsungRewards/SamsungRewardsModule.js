import React, { useMemo, useState } from 'react';
import 'scroll-shadow-element';
import SamsungTopBar from './components/SamsungTopBar';
import CategoriesScreen from './screens/CategoriesScreen';
import BenefitsScreen from './screens/BenefitsScreen';
import LoginScreen from './screens/LoginScreen';
import MigrationIntroScreen from './screens/MigrationIntroScreen';
import OtpScreen from './screens/OtpScreen';
import ProductsScreen from './screens/ProductsScreen';
import UpgradeSuccessScreen from './screens/UpgradeSuccessScreen';
import { categoryItems, productItems, qrImage, samsungAssets, samsungScreens } from './data/samsungRewardsData';
import './styles/samsung-rewards-module.css';

const defaultCategory = categoryItems[0];

function formatPhoneLabel(phoneNumber) {
  const digits = phoneNumber.replace(/\D/g, '').slice(0, 10);

  if (!digits) {
    return '+91 98959 905 032';
  }

  const first = digits.slice(0, 5);
  const second = digits.slice(5, 8);
  const third = digits.slice(8, 10);

  return ['+91', first, second, third].filter(Boolean).join(' ');
}

function SamsungRewardsModule() {
  const [screen, setScreen] = useState(samsungScreens.migration);
  const [mobileNumber, setMobileNumber] = useState('9895990503');
  const [otp, setOtp] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(defaultCategory);

  const phoneLabel = useMemo(() => formatPhoneLabel(mobileNumber), [mobileNumber]);

  return (
    <section className="samsung-module-wrapper">
      <div className="samsung-module-wrapper__ambient samsung-module-wrapper__ambient--one" />
      <div className="samsung-module-wrapper__ambient samsung-module-wrapper__ambient--two" />

      <div className="samsung-app-shell">
        <SamsungTopBar />

        <scroll-shadow className="samsung-scroll-region">
          <main key={screen} className="samsung-device-content">
            {screen === samsungScreens.migration && (
              <MigrationIntroScreen
                iconSrc={samsungAssets.migrationIcon}
                onMigrate={() => setScreen(samsungScreens.login)}
                onSkip={() => setScreen(samsungScreens.benefits)}
              />
            )}

            {screen === samsungScreens.login && (
              <LoginScreen
                mobileNumber={mobileNumber}
                onMobileChange={setMobileNumber}
                onSubmit={() => setScreen(samsungScreens.otp)}
              />
            )}

            {screen === samsungScreens.otp && (
              <OtpScreen
                otp={otp}
                onOtpChange={setOtp}
                phoneLabel={phoneLabel}
                onSubmit={() => setScreen(samsungScreens.success)}
              />
            )}

            {screen === samsungScreens.success && (
              <UpgradeSuccessScreen
                backgroundImage={samsungAssets.successBackground}
                illustration={samsungAssets.congratulationsIllustration}
                onNext={() => setScreen(samsungScreens.categories)}
              />
            )}

            {screen === samsungScreens.categories && (
              <CategoriesScreen
                userName="Johnny Bravo"
                phoneLabel={phoneLabel}
                rewardPoints="2000"
                rewardIcon={samsungAssets.rewardsWalletIcon}
                items={categoryItems}
                onSelect={(item) => {
                  setSelectedCategory(item);
                  setScreen(samsungScreens.products);
                }}
              />
            )}

            {screen === samsungScreens.products && (
              <ProductsScreen
                categoryTitle={selectedCategory.title}
                rewardPoints="2000"
                rewardIcon={samsungAssets.rewardsWalletIcon}
                items={productItems}
                onNext={() => setScreen(samsungScreens.benefits)}
              />
            )}

            {screen === samsungScreens.benefits && <BenefitsScreen qrImage={qrImage} />}
          </main>
        </scroll-shadow>
      </div>
    </section>
  );
}

export default SamsungRewardsModule;
