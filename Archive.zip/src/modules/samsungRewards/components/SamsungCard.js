import React from 'react';

function SamsungCard({ item, variant, isActive, onClick }) {
  const cardClassName = `samsung-card samsung-card--${variant} ${isActive ? 'is-active' : ''}`.trim();

  if (variant === 'category') {
    return (
      <button type="button" className={cardClassName} onClick={() => onClick(item)}>
        <div className="samsung-card__media samsung-card__media--category">
          <img src={item.image} alt={item.title} className="samsung-card__image" />
        </div>
        <div className="samsung-card__body samsung-card__body--category">
          <p className="samsung-card__eyebrow samsung-card__eyebrow--category">{item.eyebrow}</p>
          <h3 className="samsung-card__title samsung-card__title--category">{item.title}</h3>
          <p className="samsung-card__subtitle">{item.subtitle}</p>
          <span className="samsung-card__action">View curated offers</span>
        </div>
      </button>
    );
  }

  return (
    <article className={cardClassName}>
      <span className={`samsung-card__badge samsung-card__badge--${item.badgeTone || 'accent'}`}>{item.badge}</span>
      <div className="samsung-card__media samsung-card__media--product">
        <img src={item.image} alt={item.title} className="samsung-card__image" />
      </div>
      <div className="samsung-card__body">
        <p className="samsung-card__eyebrow">{item.eyebrow}</p>
        <h3 className="samsung-card__title">{item.title}</h3>
        <div className="samsung-card__feature-grid">
          {item.features.map((feature) => (
            <div key={feature.label} className="samsung-card__feature-item">
              <span className="samsung-card__feature-icon">
                <img src={feature.icon} alt="" className="samsung-card__feature-icon-image" />
              </span>
              <span>{feature.label}</span>
            </div>
          ))}
        </div>
      </div>
    </article>
  );
}

export default SamsungCard;
