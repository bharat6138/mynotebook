import React from 'react';
import { samsungAssets } from '../data/samsungRewardsData';

function SamsungTopBar() {
  return (
    <header className="samsung-topbar" role="banner">
      <div className="samsung-topbar__inner">
        <div className="samsung-topbar__brand" aria-label="Samsung">
          <img src={samsungAssets.samsungWordmark} alt="Samsung" className="samsung-topbar__logo" />
        </div>

        <div className="samsung-topbar__actions" aria-label="Quick actions">
          <button type="button" className="samsung-topbar__icon-button" aria-label="Home">
            <img src={samsungAssets.homeIcon} alt="" className="samsung-topbar__icon" />
          </button>
          <button type="button" className="samsung-topbar__icon-button" aria-label="Search">
            <img src={samsungAssets.searchIcon} alt="" className="samsung-topbar__icon" />
          </button>
        </div>
      </div>
    </header>
  );
}

export default SamsungTopBar;
