import React, { useEffect, useMemo, useRef, useState } from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import SamsungCard from './SamsungCard';

// Set this to false to disable autoplay globally.
const ENABLE_AUTOPLAY = true;
const AUTOPLAY_INTERVAL = 4000;
// Set this to true to inspect live slider widths in the browser console.
const DEBUG_SLIDER_WIDTH = false;

// Adjust the card counts here for each screen size.
const SLIDER_LAYOUT = {
  mobile: 1,
  tablet: {
    category: 2,
    product: 2,
  },
  laptop: {
    category: 3,
    product: 2,
  },
  desktop: {
    category: 3,
    product: 3,
  },
};

function getSlidesToShow(viewportWidth, variant) {
  if (viewportWidth >= 1280) {
    return SLIDER_LAYOUT.desktop[variant];
  }

  if (viewportWidth >= 992) {
    return SLIDER_LAYOUT.laptop[variant];
  }

  if (viewportWidth >= 768) {
    return SLIDER_LAYOUT.tablet[variant];
  }

  return SLIDER_LAYOUT.mobile;
}

function SamsungProductSlider({ items, variant, onItemClick }) {
  const sliderRef = useRef(null);
  const sliderShellRef = useRef(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [viewportWidth, setViewportWidth] = useState(() =>
    typeof window === 'undefined' ? 1440 : window.innerWidth
  );

  const slidesVisible = getSlidesToShow(viewportWidth, variant);
  const canSlide = items.length > slidesVisible;
  const isDesktopViewport = viewportWidth >= 992;
  const sliderInstanceKey = `${variant}-${items.length}-${slidesVisible}`;

  useEffect(() => {
    setActiveIndex(0);
  }, [items, variant]);

  useEffect(() => {
    const handleResize = () => {
      setViewportWidth(window.innerWidth);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    if (!DEBUG_SLIDER_WIDTH || !sliderShellRef.current) {
      return undefined;
    }

    const logTimer = window.setTimeout(() => {
      const shell = sliderShellRef.current;
      const list = shell.querySelector('.slick-list');
      const track = shell.querySelector('.slick-track');
      const slide = shell.querySelector('.slick-slide:not(.slick-cloned)');

      console.log('[SamsungSlider]', {
        variant,
        viewportWidth,
        shellWidth: shell?.getBoundingClientRect().width,
        listWidth: list?.getBoundingClientRect().width,
        trackWidth: track?.getBoundingClientRect().width,
        firstSlideWidth: slide?.getBoundingClientRect().width,
        activeIndex,
      });
    }, 80);

    return () => {
      window.clearTimeout(logTimer);
    };
  }, [activeIndex, variant, viewportWidth]);

  const settings = useMemo(
    () => ({
      accessibility: true,
      arrows: false,
      dots: variant === 'category' && canSlide,
      infinite: false,
      speed: 520,
      // Autoplay is desktop-only. Mobile and tablet stay swipe-only.
      autoplay: ENABLE_AUTOPLAY && canSlide && isDesktopViewport,
      autoplaySpeed: AUTOPLAY_INTERVAL,
      pauseOnHover: true,
      pauseOnFocus: true,
      pauseOnDotsHover: true,
      focusOnSelect: false,
      slidesToShow: SLIDER_LAYOUT.mobile,
      slidesToScroll: 1,
      mobileFirst: true,
      respondTo: 'window',
      centerMode: false,
      centerPadding: '0px',
      adaptiveHeight: false,
      edgeFriction: 0.08,
      swipe: true,
      swipeToSlide: true,
      variableWidth: false,
      draggable: true,
      touchMove: true,
      touchThreshold: 8,
      waitForAnimate: false,
      vertical: false,
      verticalSwiping: false,
      lazyLoad: 'ondemand',
      cssEase: 'cubic-bezier(0.22, 1, 0.36, 1)',
      beforeChange: (_, next) => setActiveIndex(next),
      afterChange: (current) => setActiveIndex(current),
      responsive: [
        {
          breakpoint: 768,
          settings: {
            slidesToShow: SLIDER_LAYOUT.mobile,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 992,
          settings: {
            slidesToShow: SLIDER_LAYOUT.tablet[variant],
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 1280,
          settings: {
            slidesToShow: SLIDER_LAYOUT.laptop[variant],
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 9999,
          settings: {
            slidesToShow: SLIDER_LAYOUT.desktop[variant],
            slidesToScroll: 1,
          },
        },
      ],
    }),
    [canSlide, isDesktopViewport, variant]
  );

  return (
    <div ref={sliderShellRef} className={`samsung-slider-shell samsung-slider-shell--${variant}`}>
      <Slider ref={sliderRef} key={sliderInstanceKey} {...settings}>
        {items.map((item, index) => (
          <div key={item.id} className="samsung-slider-shell__slide">
            <div className={`samsung-slider-shell__scale ${activeIndex === index ? 'is-active' : ''}`}>
              <SamsungCard
                item={item}
                variant={variant}
                isActive={activeIndex === index}
                onClick={onItemClick}
              />
            </div>
          </div>
        ))}
      </Slider>

      {canSlide && (
        <div className="samsung-slider-shell__desktop-nav">
          <button
            type="button"
            className="samsung-slider-shell__nav-btn samsung-slider-shell__nav-btn--prev"
            onClick={() => sliderRef.current?.slickPrev()}
          >
            Previous
          </button>
          <button
            type="button"
            className="samsung-slider-shell__nav-btn samsung-slider-shell__nav-btn--next"
            onClick={() => sliderRef.current?.slickNext()}
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
}

export default SamsungProductSlider;
