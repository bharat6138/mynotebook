import React from 'react';

function UpgradeSuccessScreen({ backgroundImage, illustration, onNext }) {
  return (
    <div className="samsung-screen-card samsung-screen-card--center samsung-fade-up">
      <div className="samsung-success-showcase">
        <img src={backgroundImage} alt="" className="samsung-success-showcase__background" />
        <div className="samsung-success-showcase__glow samsung-success-showcase__glow--one" aria-hidden="true" />
        <div className="samsung-success-showcase__glow samsung-success-showcase__glow--two" aria-hidden="true" />
        <div className="samsung-success-showcase__ring samsung-success-showcase__ring--one" aria-hidden="true" />
        <div className="samsung-success-showcase__ring samsung-success-showcase__ring--two" aria-hidden="true" />

        <div className="samsung-success-visual" aria-hidden="true">
          <img src={illustration} alt="" className="samsung-success-visual__image" />
        </div>

        <div className="samsung-success-badge">Samsung Rewards upgraded</div>
      </div>

      <h2 className="samsung-screen-title samsung-screen-title--accent">Congratulations</h2>
      <p className="samsung-screen-copy">on upgrading to Samsung Rewards.</p>
      <p className="samsung-screen-copy samsung-screen-copy--narrow">
        Welcome to an all-new rewarding experience.
      </p>

      <button type="button" className="btn samsung-btn samsung-btn--primary" onClick={onNext}>
        Next
      </button>
    </div>
  );
}

export default UpgradeSuccessScreen;
