import React from 'react';

function LoginScreen({ mobileNumber, onMobileChange, onSubmit }) {
  return (
    <div className="samsung-screen-card samsung-fade-up">
      <h2 className="samsung-section-heading samsung-section-heading--center">
        Upgrading to a new rewarding experience
      </h2>
      <p className="samsung-screen-copy samsung-screen-copy--narrow samsung-screen-copy--centered">
        Confirm your registered number to continue the Samsung Rewards migration securely.
      </p>

      <div className="samsung-form-shell">
        <div className="samsung-field-group">
          <label htmlFor="mobileNumber" className="samsung-field-label">
            Enter your mobile number
          </label>
          <input
            id="mobileNumber"
            type="tel"
            className="form-control samsung-input"
            value={mobileNumber}
            onChange={(event) => onMobileChange(event.target.value)}
            placeholder="Enter mobile number"
          />
          <p className="samsung-field-helper">We will send a one-time password to verify your rewards account.</p>
        </div>

        <div className="samsung-captcha-panel">
          <p className="samsung-captcha-panel__label">Security validation</p>
          <div className="samsung-captcha-row">
            <div className="samsung-captcha-text">bowl!95Vk</div>
            <button type="button" className="samsung-link-button">
              Refresh Captcha
            </button>
          </div>
          <input
            type="text"
            className="form-control samsung-input samsung-input--captcha"
            placeholder="Type captcha here"
            aria-label="Enter captcha"
          />
        </div>

        <button type="button" className="btn samsung-btn samsung-btn--primary samsung-btn--full" onClick={onSubmit}>
          Login via OTP
        </button>
      </div>
    </div>
  );
}

export default LoginScreen;
