import React from 'react';
import SamsungProductSlider from '../components/SamsungProductSlider';

function ProductsScreen({ categoryTitle, rewardPoints, rewardIcon, items, onNext }) {
  return (
    <div className="samsung-screen-shell samsung-fade-up">
      <div className="samsung-user-row samsung-user-row--compact">
        <div>
          <p className="samsung-user-row__label">Selected category</p>
          <p className="samsung-user-row__name">{categoryTitle}</p>
        </div>
        <div className="samsung-points-pill">
          <img src={rewardIcon} alt="" className="samsung-points-pill__icon" />
          <span>{rewardPoints}</span>
        </div>
      </div>

      <div className="samsung-content-heading">
        <h3 className="samsung-content-heading__title">Recommended Products</h3>
        <p className="samsung-content-heading__copy">
          Personalized picks based on your interest in {categoryTitle}
        </p>
      </div>

      <SamsungProductSlider items={items} variant="product" />

      <div className="samsung-footer-cta">
        <button type="button" className="btn samsung-btn samsung-btn--primary" onClick={onNext}>
          Next
        </button>
      </div>
    </div>
  );
}

export default ProductsScreen;
