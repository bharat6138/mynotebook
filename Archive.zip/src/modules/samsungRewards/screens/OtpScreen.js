import React, { useMemo, useRef } from 'react';

function OtpScreen({ otp, onOtpChange, phoneLabel, onSubmit }) {
  const inputRefs = useRef([]);
  const otpDigits = useMemo(() => Array.from({ length: 6 }, (_, index) => otp[index] || ''), [otp]);

  const focusInput = (index) => {
    const nextInput = inputRefs.current[index];

    if (nextInput) {
      nextInput.focus();
      nextInput.select();
    }
  };

  const updateOtpAtIndex = (index, value) => {
    const nextDigits = [...otpDigits];
    nextDigits[index] = value;
    onOtpChange(nextDigits.join(''));
  };

  const handleInputChange = (index, event) => {
    const value = event.target.value.replace(/\D/g, '');

    if (!value) {
      updateOtpAtIndex(index, '');
      return;
    }

    if (value.length > 1) {
      const nextDigits = [...otpDigits];

      value.slice(0, 6 - index).split('').forEach((digit, offset) => {
        nextDigits[index + offset] = digit;
      });

      onOtpChange(nextDigits.join(''));
      focusInput(Math.min(index + value.length, 5));
      return;
    }

    updateOtpAtIndex(index, value);

    if (index < 5) {
      focusInput(index + 1);
    }
  };

  const handleKeyDown = (index, event) => {
    if (event.key === 'Backspace') {
      event.preventDefault();

      if (otpDigits[index]) {
        updateOtpAtIndex(index, '');
        return;
      }

      if (index > 0) {
        updateOtpAtIndex(index - 1, '');
        focusInput(index - 1);
      }
    }

    if (event.key === 'ArrowLeft' && index > 0) {
      event.preventDefault();
      focusInput(index - 1);
    }

    if (event.key === 'ArrowRight' && index < 5) {
      event.preventDefault();
      focusInput(index + 1);
    }
  };

  const handlePaste = (event) => {
    const pastedValue = event.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);

    if (!pastedValue) {
      return;
    }

    event.preventDefault();
    onOtpChange(pastedValue);
    focusInput(Math.min(pastedValue.length - 1, 5));
  };

  return (
    <div className="samsung-screen-card samsung-fade-up">
      <h2 className="samsung-section-heading samsung-section-heading--center">
        Upgrade to a new rewarding experience
      </h2>
      <p className="samsung-screen-copy samsung-screen-copy--narrow samsung-screen-copy--centered">
        Enter the secure code sent to your registered mobile number to complete the upgrade.
      </p>

      <div className="samsung-form-shell">
        <div className="samsung-field-group">
          <label htmlFor="otp-digit-0" className="samsung-field-label">
            Enter your OTP code
          </label>
          <div className="samsung-otp-inputs" onPaste={handlePaste}>
            {otpDigits.map((digit, index) => (
              <input
                key={`otp-${index}`}
                id={`otp-digit-${index}`}
                ref={(element) => {
                  inputRefs.current[index] = element;
                }}
                type="text"
                inputMode="numeric"
                autoComplete={index === 0 ? 'one-time-code' : 'off'}
                className="form-control samsung-input samsung-input--otp-slot"
                value={digit}
                maxLength={1}
                aria-label={`OTP digit ${index + 1}`}
                onChange={(event) => handleInputChange(index, event)}
                onKeyDown={(event) => handleKeyDown(index, event)}
              />
            ))}
          </div>
          <p className="samsung-field-helper">Enter the 6-digit code exactly as received.</p>
        </div>

        <p className="samsung-meta samsung-meta--success">OTP sent to {phoneLabel}</p>
        <p className="samsung-meta">03:17 sec</p>

        <button type="button" className="samsung-link-button samsung-link-button--center">
          Resend OTP
        </button>

        <button
          type="button"
          className="btn samsung-btn samsung-btn--accent samsung-btn--full"
          onClick={onSubmit}
          disabled={otp.length !== 6}
        >
          Submit
        </button>
      </div>
    </div>
  );
}

export default OtpScreen;
