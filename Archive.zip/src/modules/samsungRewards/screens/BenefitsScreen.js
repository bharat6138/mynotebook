import React from 'react';

function BenefitsScreen({ qrImage }) {
  return (
    <div className="samsung-screen-card samsung-screen-card--center samsung-fade-up">
      <p className="samsung-screen-kicker">Samsung Rewards active</p>
      <h2 className="samsung-screen-title samsung-screen-title--accent">Benefits unlocked!</h2>
      <p className="samsung-screen-copy samsung-screen-copy--narrow">
        Scan the QR code after purchase for an express checkout.
      </p>

      <div className="samsung-qr-card">
        <img src={qrImage} alt="Samsung Rewards QR" className="samsung-qr-card__image" />
      </div>

      <p className="samsung-meta samsung-meta--compact">Present this code at checkout to accelerate your rewards redemption.</p>

      <button type="button" className="btn samsung-btn samsung-btn--primary">
        Scan me
      </button>
    </div>
  );
}

export default BenefitsScreen;
