import React from 'react';
import SamsungProductSlider from '../components/SamsungProductSlider';

function CategoriesScreen({ userName, phoneLabel, rewardPoints, rewardIcon, items, onSelect }) {
  return (
    <div className="samsung-screen-shell samsung-fade-up">
      <div className="samsung-user-row">
        <div>
          <p className="samsung-user-row__label">Samsung Rewards Member</p>
          <p className="samsung-user-row__name">{userName}</p>
          <p className="samsung-user-row__phone">{phoneLabel}</p>
        </div>
        <div className="samsung-points-pill">
          <img src={rewardIcon} alt="" className="samsung-points-pill__icon" />
          <span>{rewardPoints}</span>
        </div>
      </div>

      <div className="samsung-content-heading">
        <h3 className="samsung-content-heading__title">Product Categories</h3>
        <p className="samsung-content-heading__copy">
          Select from below categories to get personalized offerings
        </p>
      </div>

      <SamsungProductSlider items={items} variant="category" onItemClick={onSelect} />
    </div>
  );
}

export default CategoriesScreen;
