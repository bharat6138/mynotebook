import React from 'react';

function MigrationIntroScreen({ iconSrc, onMigrate, onSkip }) {
  return (
    <div className="samsung-screen-card samsung-screen-card--center samsung-fade-up">
      <div className="samsung-brand-icon" aria-hidden="true">
        <img src={iconSrc} alt="" className="samsung-brand-icon__image" />
      </div>

      <p className="samsung-screen-kicker">Samsung enterprise rewards</p>
      <h1 className="samsung-screen-title">SmartClub</h1>
      <h2 className="samsung-screen-subtitle">is now Samsung Rewards</h2>
      <p className="samsung-screen-copy samsung-screen-copy--narrow">
        Move your existing SmartClub benefits into a more premium Samsung Rewards experience.
      </p>

      <div className="samsung-button-stack">
        <button type="button" className="btn samsung-btn samsung-btn--primary" onClick={onMigrate}>
          Yes, migrate/enroll
        </button>
        <button type="button" className="btn samsung-btn samsung-btn--secondary" onClick={onSkip}>
          No, skip
        </button>
      </div>
    </div>
  );
}

export default MigrationIntroScreen;
