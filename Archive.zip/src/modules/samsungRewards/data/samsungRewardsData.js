const assetBase = '/images/samsung-rewards';

const benefitIcons = {
  discover: `${assetBase}/icons/benefit-discover.svg`,
  finance: `${assetBase}/icons/benefit-finance.svg`,
  rewards: `${assetBase}/icons/benefit-rewards.svg`,
};

export const samsungAssets = {
  migrationIcon: `${assetBase}/icons/migration-arrows.svg`,
  rewardsWalletIcon: `${assetBase}/icons/wallet-points.svg`,
  samsungWordmark: `${assetBase}/icons/samsung-wordmark.svg`,
  homeIcon: `${assetBase}/icons/home.svg`,
  searchIcon: `${assetBase}/icons/search.svg`,
  successBackground: `${assetBase}/illustrations/success-background.svg`,
  congratulationsIllustration: `${assetBase}/illustrations/congratulations.svg`,
  qrCode: `${assetBase}/qr/benefits-qr.svg`,
};

export const samsungScreens = {
  migration: 'migration',
  login: 'login',
  otp: 'otp',
  success: 'success',
  categories: 'categories',
  products: 'products',
  benefits: 'benefits',
};

export const categoryItems = [
  {
    id: 1,
    title: 'Smartphones',
    subtitle: 'Personalized flagship offers and foldable upgrades',
    eyebrow: 'Galaxy ecosystem',
    image: `${assetBase}/categories/smartphones.svg`,
  },
  {
    id: 2,
    title: 'TVs',
    subtitle: 'Premium viewing experiences with enterprise value',
    eyebrow: 'Home entertainment',
    image: `${assetBase}/categories/tvs.svg`,
  },
  {
    id: 3,
    title: 'Wearables',
    subtitle: 'Connected accessories curated for everyday performance',
    eyebrow: 'Smart lifestyle',
    image: `${assetBase}/categories/wearables.svg`,
  },
];

export const productItems = [
  {
    id: 1,
    title: 'Galaxy Z Fold7',
    badge: 'EXCLUSIVE',
    badgeTone: 'accent',
    image: `${assetBase}/products/galaxy-z-fold7.svg`,
    eyebrow: 'Next-gen productivity',
    features: [
      { label: 'Exchange bonus', icon: benefitIcons.discover },
      { label: 'Flexible finance', icon: benefitIcons.finance },
      { label: 'Rewards multiplier', icon: benefitIcons.rewards },
    ],
  },
  {
    id: 2,
    title: 'Galaxy S24 Ultra',
    badge: 'RECOMMENDED',
    badgeTone: 'warm',
    image: `${assetBase}/products/galaxy-s24-ultra.svg`,
    eyebrow: 'Built for business and creativity',
    features: [
      { label: 'Instant bank offer', icon: benefitIcons.discover },
      { label: 'Zero-cost EMI', icon: benefitIcons.finance },
      { label: 'Premium care', icon: benefitIcons.rewards },
    ],
  },
  {
    id: 3,
    title: 'Neo QLED 8K',
    badge: 'TOP PICK',
    badgeTone: 'dark',
    image: `${assetBase}/products/neo-qled-8k.svg`,
    eyebrow: 'Immersive premium entertainment',
    features: [
      { label: 'Installation support', icon: benefitIcons.discover },
      { label: 'No-cost EMI', icon: benefitIcons.finance },
      { label: 'Reward points', icon: benefitIcons.rewards },
    ],
  },
];

export const qrImage = samsungAssets.qrCode;
