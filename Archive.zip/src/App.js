import React from 'react';
import SamsungRewardsModule from './modules/samsungRewards/SamsungRewardsModule';

function App() {
  return <SamsungRewardsModule />;
}

export default App;
