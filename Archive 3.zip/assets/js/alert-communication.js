const alertCommunicationState = {
  sort: 'latest',
  bulkMode: 'to',
  selectedRecipientIds: [],
  maxRecipients: 50,
  activeGroupId: 'RQID00001',
  groups: [
    {
      id: 'RQID00001',
      name: 'L1',
      category: 'Application',
      subCategory: 'DMS',
      date: '2024-09-25',
      status: 'active',
      members: [
        {
          id: 'EMP001',
          name: 'Anil Kumar',
          email: 'anil.k1@samsung.com',
          phone: '9855847455',
          team: 'VDI / Tech Support Group / SDSI',
          mailStatus: 'To',
          channels: {
            knoxMail: true,
            knoxAnnouncement: true,
            knoxMessenger: true,
            whatsapp: false,
            sms: false
          }
        },
        {
          id: 'EMP002',
          name: 'Sameer Khanna',
          email: 'sameer.k@samsung.com',
          phone: '9956251488',
          team: 'VDI / Tech Support Group / SDSI',
          mailStatus: 'CC',
          channels: {
            knoxMail: true,
            knoxAnnouncement: true,
            knoxMessenger: true,
            whatsapp: false,
            sms: false
          }
        },
        {
          id: 'EMP003',
          name: 'Vikrant Singh',
          email: 's.vikrant@samsung.com',
          phone: '9722551477',
          team: 'VDI / Tech Support Group / SDSI',
          mailStatus: 'To',
          channels: {
            knoxMail: true,
            knoxAnnouncement: false,
            knoxMessenger: false,
            whatsapp: false,
            sms: true
          }
        }
      ],
      modes: [
        { key: 'knoxMail', label: 'Knox mail', description: 'Send alert details through Knox Mail', active: true },
        { key: 'knoxAnnouncement', label: 'Knox announcement', description: 'Post alert summary to the announcement feed', active: true },
        { key: 'knoxMessenger', label: 'Knox messenger', description: 'Push messages directly to team members', active: true },
        { key: 'whatsapp', label: 'WhatsApp', description: 'Fallback outreach for mobile-first teams', active: false },
        { key: 'caller', label: 'Caller', description: 'Voice escalation for priority incidents', active: false },
        { key: 'sms', label: 'SMS', description: 'Text delivery for urgent communication', active: false }
      ]
    },
    {
      id: 'RQID00002',
      name: 'L2',
      category: 'Infrastructure',
      subCategory: 'Network',
      date: '2024-09-25',
      status: 'active',
      members: [
        {
          id: 'EMP004',
          name: 'Priya Nair',
          email: 'priya.nair@samsung.com',
          phone: '9881122233',
          team: 'Infra Core / Network Operations',
          mailStatus: 'To',
          channels: {
            knoxMail: true,
            knoxAnnouncement: true,
            knoxMessenger: false,
            whatsapp: true,
            sms: true
          }
        },
        {
          id: 'EMP005',
          name: 'Rohit Verma',
          email: 'rohit.verma@samsung.com',
          phone: '9780011223',
          team: 'Infra Core / Network Operations',
          mailStatus: 'BCC',
          channels: {
            knoxMail: true,
            knoxAnnouncement: false,
            knoxMessenger: true,
            whatsapp: true,
            sms: false
          }
        }
      ],
      modes: [
        { key: 'knoxMail', label: 'Knox mail', description: 'Send alert details through Knox Mail', active: true },
        { key: 'knoxAnnouncement', label: 'Knox announcement', description: 'Post alert summary to the announcement feed', active: true },
        { key: 'knoxMessenger', label: 'Knox messenger', description: 'Push messages directly to team members', active: false },
        { key: 'whatsapp', label: 'WhatsApp', description: 'Fallback outreach for mobile-first teams', active: true },
        { key: 'caller', label: 'Caller', description: 'Voice escalation for priority incidents', active: false },
        { key: 'sms', label: 'SMS', description: 'Text delivery for urgent communication', active: true }
      ]
    },
    {
      id: 'RQID00003',
      name: 'Escalation Desk',
      category: 'Operations',
      subCategory: 'Incident Response',
      date: '2024-08-19',
      status: 'draft',
      members: [
        {
          id: 'EMP006',
          name: 'Karan Patel',
          email: 'karan.patel@samsung.com',
          phone: '9730091234',
          team: 'Ops / Incident Desk',
          mailStatus: 'To',
          channels: {
            knoxMail: true,
            knoxAnnouncement: false,
            knoxMessenger: true,
            whatsapp: false,
            sms: true
          }
        }
      ],
      modes: [
        { key: 'knoxMail', label: 'Knox mail', description: 'Send alert details through Knox Mail', active: true },
        { key: 'knoxAnnouncement', label: 'Knox announcement', description: 'Post alert summary to the announcement feed', active: false },
        { key: 'knoxMessenger', label: 'Knox messenger', description: 'Push messages directly to team members', active: true },
        { key: 'whatsapp', label: 'WhatsApp', description: 'Fallback outreach for mobile-first teams', active: false },
        { key: 'caller', label: 'Caller', description: 'Voice escalation for priority incidents', active: false },
        { key: 'sms', label: 'SMS', description: 'Text delivery for urgent communication', active: true }
      ]
    }
  ],
  recipientDirectory: [
    {
      id: 'REC001',
      name: 'Anil Kumar',
      knoxId: 'anil.k1',
      email: 'anil.k1@samsung.com',
      team: 'VDI / Tech Support Group / SDSI',
      badge: 'L1 Support',
      mode: 'to'
    },
    {
      id: 'REC002',
      name: 'Sameer Khanna',
      knoxId: 'sameer.k',
      email: 'sameer.k@samsung.com',
      team: 'VDI / Tech Support Group / SDSI',
      badge: 'Shift Lead',
      mode: 'cc'
    },
    {
      id: 'REC003',
      name: 'Vikrant Singh',
      knoxId: 's.vikrant',
      email: 's.vikrant@samsung.com',
      team: 'VDI / Tech Support Group / SDSI',
      badge: 'VDI Expert',
      mode: 'to'
    },
    {
      id: 'REC004',
      name: 'Priya Nair',
      knoxId: 'priya.nair',
      email: 'priya.nair@samsung.com',
      team: 'Infra Core / Network Operations',
      badge: 'Infra Core',
      mode: null
    },
    {
      id: 'REC005',
      name: 'Rohit Verma',
      knoxId: 'rohit.verma',
      email: 'rohit.verma@samsung.com',
      team: 'Infra Core / Network Operations',
      badge: 'Network Ops',
      mode: 'bcc'
    },
    {
      id: 'REC006',
      name: 'Karan Patel',
      knoxId: 'karan.patel',
      email: 'karan.patel@samsung.com',
      team: 'Ops / Incident Desk',
      badge: 'Incident Desk',
      mode: null
    },
    {
      id: 'REC007',
      name: 'Maya Chopra',
      knoxId: 'maya.chopra',
      email: 'maya.chopra@samsung.com',
      team: 'Application Reliability',
      badge: 'Application SME',
      mode: null
    },
    {
      id: 'REC008',
      name: 'Aarav Sen',
      knoxId: 'aarav.sen',
      email: 'aarav.sen@samsung.com',
      team: 'Business Messaging',
      badge: 'Messaging',
      mode: null
    }
  ]
};

const dom = {};
let membersModalInstance;
let alertModeDrawerInstance;
let activeRecipientChipId = null;
let toastTimer;
let overlayLockDepth = 0;
let lockedScrollY = 0;

function shouldUseFullscreenOverlay() {
  return window.matchMedia('(max-width: 991.98px)').matches;
}

function lockViewportForOverlay() {
  if (!shouldUseFullscreenOverlay()) return;

  if (overlayLockDepth === 0) {
    lockedScrollY = window.scrollY || window.pageYOffset || 0;
    document.body.style.position = 'fixed';
    document.body.style.top = `-${lockedScrollY}px`;
    document.body.style.left = '0';
    document.body.style.right = '0';
    document.body.style.width = '100%';
    document.body.style.overflow = 'hidden';
    document.body.style.paddingRight = '0';
  }

  overlayLockDepth += 1;
}

function unlockViewportForOverlay() {
  if (!shouldUseFullscreenOverlay()) return;

  overlayLockDepth = Math.max(overlayLockDepth - 1, 0);
  if (overlayLockDepth > 0) return;

  document.body.style.position = '';
  document.body.style.top = '';
  document.body.style.left = '';
  document.body.style.right = '';
  document.body.style.width = '';
  document.body.style.overflow = '';
  document.body.style.paddingRight = '';
  window.scrollTo(0, lockedScrollY);
}

function bindOverlayViewportBehavior() {
  const membersModal = document.getElementById('membersModal');
  const alertModeDrawer = document.getElementById('alertModeDrawer');

  membersModal.addEventListener('show.bs.modal', lockViewportForOverlay);
  membersModal.addEventListener('hidden.bs.modal', unlockViewportForOverlay);
  alertModeDrawer.addEventListener('show.bs.offcanvas', lockViewportForOverlay);
  alertModeDrawer.addEventListener('hidden.bs.offcanvas', unlockViewportForOverlay);

  window.addEventListener('resize', () => {
    if (shouldUseFullscreenOverlay()) return;
    if (overlayLockDepth === 0) return;

    overlayLockDepth = 1;
    unlockViewportForOverlay();
  });
}

function formatDate(value) {
  return new Intl.DateTimeFormat('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  }).format(new Date(value));
}

function capitalize(value) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function getGroupById(groupId) {
  return alertCommunicationState.groups.find((group) => group.id === groupId);
}

function getFilteredGroups() {
  const status = dom.groupStatus.value;
  const search = dom.searchGroup.value.trim().toLowerCase();

  const filtered = alertCommunicationState.groups.filter((group) => {
    const matchesStatus = status === 'all' || group.status === status;
    const haystack = `${group.id} ${group.name} ${group.category} ${group.subCategory}`.toLowerCase();
    const matchesSearch = !search || haystack.includes(search);
    return matchesStatus && matchesSearch;
  });

  return filtered.sort((first, second) => {
    if (alertCommunicationState.sort === 'oldest') {
      return new Date(first.date) - new Date(second.date);
    }
    if (alertCommunicationState.sort === 'members') {
      return second.members.length - first.members.length;
    }
    return new Date(second.date) - new Date(first.date);
  });
}

function renderGroups() {
  const groups = getFilteredGroups();

  dom.emptyState.classList.toggle('d-none', groups.length > 0);
  dom.groupList.classList.toggle('d-none', groups.length === 0);

  dom.groupList.innerHTML = groups
    .map((group, index) => {
      const showExpanded = index === 0;
      return `
        <article class="acu-group-card" data-group-id="${group.id}">
          <div class="acu-group-header">
            <div>
              <span class="acu-group-field-label">Group ID</span>
              <div class="acu-group-field-value">${group.id}</div>
            </div>
            <div>
              <span class="acu-group-field-label">Group name</span>
              <div class="acu-group-field-value">${group.name}</div>
            </div>
            <div>
              <span class="acu-group-field-label">Category</span>
              <div class="acu-group-field-value">${group.category}</div>
            </div>
            <div>
              <span class="acu-group-field-label">Sub-category</span>
              <div class="acu-group-field-value">${group.subCategory}</div>
            </div>
            <div>
              <span class="acu-group-field-label">Date</span>
              <div class="acu-group-field-value">${formatDate(group.date)}<br /><small>${group.members.length} members</small></div>
            </div>
            <div class="acu-group-actions">
              <button class="btn acu-comm-mode-btn" type="button" data-open-alert-mode="${group.id}">
                <i class="bi bi-broadcast"></i>
                <span>Communication Mode</span>
              </button>
              <button class="btn acu-icon-btn" type="button" data-open-members="${group.id}" aria-label="Edit members for ${group.name}">
                <i class="bi bi-pencil"></i>
              </button>
              <button class="acu-collapse-btn" type="button" data-bs-toggle="collapse" data-bs-target="#groupBody-${group.id}" aria-expanded="${showExpanded}" aria-controls="groupBody-${group.id}">
                <i class="bi ${showExpanded ? 'bi-chevron-up' : 'bi-chevron-down'}"></i>
              </button>
            </div>
          </div>
          <div id="groupBody-${group.id}" class="collapse ${showExpanded ? 'show' : ''}">
            <div class="acu-group-body">
              <div class="acu-group-toolbar">
                <div>
                  <h3 class="acu-section-title mb-1">Employee List</h3>
                  <div class="acu-member-count">${group.members.length} members mapped to this alert group</div>
                </div>
                <button class="btn acu-btn acu-btn-primary" type="button" data-open-members="${group.id}">
                  <i class="bi bi-person-plus"></i>
                  <span>Add Members</span>
                </button>
              </div>
              <div class="acu-table-wrap table-responsive">
                <table class="table acu-member-table align-middle">
                  <thead>
                    <tr>
                      <th>S.No.</th>
                      <th>Emp. Name</th>
                      <th>Emp. ID</th>
                      <th>Mobile Number</th>
                      <th>Mail Status</th>
                      <th>Knox Mail</th>
                      <th>Knox Announcement</th>
                      <th>Knox Messenger</th>
                      <th>WhatsApp</th>
                      <th>SMS</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${group.members.length
                      ? group.members
                          .map(
                            (member, memberIndex) => `
                          <tr>
                            <td data-label="S.No.">${memberIndex + 1}</td>
                            <td data-label="Emp. Name">
                              <span class="acu-member-name">${member.name}</span>
                              <span class="acu-member-subtext">${member.team}</span>
                            </td>
                            <td data-label="Emp. ID">${member.email}</td>
                            <td data-label="Mobile Number">${member.phone}</td>
                            <td data-label="Mail Status"><span class="acu-mail-chip">${member.mailStatus}</span></td>
                            ${['knoxMail', 'knoxAnnouncement', 'knoxMessenger', 'whatsapp', 'sms']
                              .map(
                                (channel) => `
                                  <td data-label="${capitalize(channel.replace('knox', 'Knox ').replace('whatsapp', 'WhatsApp').replace('sms', 'SMS'))}">
                                    <label class="acu-switch" aria-label="Toggle ${channel} for ${member.name}">
                                      <input
                                        type="checkbox"
                                        ${member.channels[channel] ? 'checked' : ''}
                                        data-group-id="${group.id}"
                                        data-member-id="${member.id}"
                                        data-channel="${channel}"
                                      />
                                      <span class="acu-switch-slider"></span>
                                    </label>
                                  </td>
                                `
                              )
                              .join('')}
                            <td data-label="Action">
                              <button class="acu-action-icon" type="button" data-open-members="${group.id}" aria-label="Edit ${member.name}">
                                <i class="bi bi-pencil"></i>
                              </button>
                              <button class="acu-action-icon" type="button" data-action="delete" data-delete-member="${group.id}:${member.id}" aria-label="Delete ${member.name}">
                                <i class="bi bi-trash"></i>
                              </button>
                            </td>
                          </tr>
                        `
                          )
                          .join('')
                      : `
                        <tr class="acu-member-table-empty-row">
                          <td colspan="11">
                            <div class="acu-member-table-empty-state" role="status" aria-live="polite">
                              <div class="acu-member-table-empty-icon" aria-hidden="true">
                                <i class="bi bi-person-plus"></i>
                              </div>
                              <h4>Add employees to mail</h4>
                              <p>No employees are mapped yet. Use Add Members to assign recipients to To, CC, or BCC.</p>
                            </div>
                          </td>
                        </tr>
                      `}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </article>
      `;
    })
    .join('');

  bindGroupInteractions();
}

function getRecipientCounts() {
  const recipients = alertCommunicationState.recipientDirectory;
  const to = recipients.filter((item) => item.mode === 'to').length;
  const cc = recipients.filter((item) => item.mode === 'cc').length;
  const bcc = recipients.filter((item) => item.mode === 'bcc').length;
  return {
    total: to + cc + bcc,
    to,
    cc,
    bcc
  };
}

function syncRecipientsFromGroup(groupId) {
  const group = getGroupById(groupId);
  const memberLookup = new Map(
    group.members.map((member) => [member.email.toLowerCase(), member.mailStatus.toLowerCase()])
  );

  alertCommunicationState.recipientDirectory = alertCommunicationState.recipientDirectory.map((recipient) => ({
    ...recipient,
    mode: memberLookup.get(recipient.email.toLowerCase()) || null
  }));
}

function renderRecipientCounters() {
  const counts = getRecipientCounts();
  dom.recipientCounters.innerHTML = `
    <div class="acu-counter-summary-card">
      <span class="acu-counter-summary-label">Total ${counts.total}/${alertCommunicationState.maxRecipients}</span>
    </div>
    <div class="acu-counter-summary-stats">
      <span>To ${counts.to}</span>
      <span>Cc ${counts.cc}</span>
      <span>Bcc ${counts.bcc}</span>
    </div>
  `;
}

function getFilteredRecipients() {
  const search = dom.recipientSearch.value.trim().toLowerCase();
  if (!search) {
    return [];
  }

  return alertCommunicationState.recipientDirectory.filter((recipient) => {
    const haystack = `${recipient.name} ${recipient.knoxId} ${recipient.email} ${recipient.team}`.toLowerCase();
    return haystack.includes(search);
  });
}

function getRecipientModeLabel(mode) {
  if (mode === 'cc') return 'CC';
  if (mode === 'bcc') return 'BCC';
  return 'To';
}

function getSortedRecipients(recipients = alertCommunicationState.recipientDirectory) {
  return [...recipients].sort((first, second) => {
    const firstIndex = typeof first.sortIndex === 'number' ? first.sortIndex : Number.MAX_SAFE_INTEGER;
    const secondIndex = typeof second.sortIndex === 'number' ? second.sortIndex : Number.MAX_SAFE_INTEGER;
    if (firstIndex !== secondIndex) return firstIndex - secondIndex;
    return first.name.localeCompare(second.name);
  });
}

function getRenderableRecipients() {
  return getSortedRecipients().filter((recipient) => recipient.mode);
}

function isRecipientRowSelected(recipientId) {
  return alertCommunicationState.selectedRecipientIds.includes(recipientId);
}

function toggleRecipientSelection(recipientId) {
  if (isRecipientRowSelected(recipientId)) {
    alertCommunicationState.selectedRecipientIds = alertCommunicationState.selectedRecipientIds.filter((id) => id !== recipientId);
    if (activeRecipientChipId === recipientId) activeRecipientChipId = null;
    return;
  }

  alertCommunicationState.selectedRecipientIds = [...alertCommunicationState.selectedRecipientIds, recipientId];
  activeRecipientChipId = recipientId;
}

function clearRecipientSelection() {
  alertCommunicationState.selectedRecipientIds = [];
  activeRecipientChipId = null;
}

function getBulkTargetRecipientIds() {
  if (alertCommunicationState.selectedRecipientIds.length) {
    return alertCommunicationState.selectedRecipientIds;
  }

  return activeRecipientChipId ? [activeRecipientChipId] : [];
}

function assignModeToRecipients(recipientIds, mode) {
  if (!recipientIds.length) return;

  const recipientIdSet = new Set(recipientIds);
  alertCommunicationState.recipientDirectory = alertCommunicationState.recipientDirectory.map((recipient) => (
    recipientIdSet.has(recipient.id)
      ? { ...recipient, mode }
      : recipient
  ));
}

function initializeRecipientSortOrder() {
  alertCommunicationState.recipientDirectory = alertCommunicationState.recipientDirectory.map((recipient, index) => ({
    ...recipient,
    sortIndex: typeof recipient.sortIndex === 'number' ? recipient.sortIndex : index
  }));
}

function moveSelectedRecipients(action) {
  const targetIds = getBulkTargetRecipientIds();
  if (!targetIds.length) return;

  const selectedIdSet = new Set(targetIds);
  const orderedRecipients = getSortedRecipients();

  if (action === 'top') {
    orderedRecipients.sort((first, second) => {
      const firstSelected = selectedIdSet.has(first.id);
      const secondSelected = selectedIdSet.has(second.id);
      if (firstSelected === secondSelected) {
        return (first.sortIndex ?? 0) - (second.sortIndex ?? 0);
      }
      return firstSelected ? -1 : 1;
    });
  }

  if (action === 'bottom') {
    orderedRecipients.sort((first, second) => {
      const firstSelected = selectedIdSet.has(first.id);
      const secondSelected = selectedIdSet.has(second.id);
      if (firstSelected === secondSelected) {
        return (first.sortIndex ?? 0) - (second.sortIndex ?? 0);
      }
      return firstSelected ? 1 : -1;
    });
  }

  if (action === 'up') {
    for (let index = 1; index < orderedRecipients.length; index += 1) {
      if (selectedIdSet.has(orderedRecipients[index].id) && !selectedIdSet.has(orderedRecipients[index - 1].id)) {
        [orderedRecipients[index - 1], orderedRecipients[index]] = [orderedRecipients[index], orderedRecipients[index - 1]];
      }
    }
  }

  if (action === 'down') {
    for (let index = orderedRecipients.length - 2; index >= 0; index -= 1) {
      if (selectedIdSet.has(orderedRecipients[index].id) && !selectedIdSet.has(orderedRecipients[index + 1].id)) {
        [orderedRecipients[index], orderedRecipients[index + 1]] = [orderedRecipients[index + 1], orderedRecipients[index]];
      }
    }
  }

  const sortLookup = new Map(orderedRecipients.map((recipient, index) => [recipient.id, index]));
  alertCommunicationState.recipientDirectory = alertCommunicationState.recipientDirectory.map((recipient) => ({
    ...recipient,
    sortIndex: sortLookup.get(recipient.id) ?? recipient.sortIndex ?? Number.MAX_SAFE_INTEGER
  }));
}

function renderRecipientAutocomplete() {
  const search = dom.recipientSearch.value.trim();
  if (!search) {
    dom.recipientAutocomplete.classList.add('d-none');
    dom.recipientAutocomplete.innerHTML = '';
    return;
  }

  const suggestions = getFilteredRecipients().slice(0, 8);
  dom.recipientAutocomplete.innerHTML = suggestions.length
    ? suggestions
        .map(
          (recipient) => `
            <button
              type="button"
              class="acu-autocomplete-item"
              data-add-recipient="${recipient.id}"
              role="option"
            >
              <span class="acu-autocomplete-name">${recipient.name}</span>
              <span class="acu-autocomplete-meta">${recipient.knoxId} · ${recipient.email}</span>
            </button>
          `
        )
        .join('')
    : '<div class="acu-autocomplete-empty">No matching recipient found.</div>';

  dom.recipientAutocomplete.classList.remove('d-none');
}

function renderRecipientList() {
  const recipients = getRenderableRecipients();
  dom.clearRecipientSearch.classList.toggle('d-none', !dom.recipientSearch.value.trim());

  dom.recipientList.innerHTML = recipients.length
    ? recipients
    .map((recipient) => {
      const rowSelected = isRecipientRowSelected(recipient.id);
      const assigned = Boolean(recipient.mode);
      return `
        <article
          class="acu-recipient-item ${assigned ? 'is-assigned' : 'is-unassigned'} ${rowSelected ? 'is-multi-selected' : ''}"
          data-recipient-id="${recipient.id}"
          role="option"
          aria-selected="${rowSelected}"
          tabindex="0"
        >
          <div class="acu-recipient-primary acu-recipient-primary-compact">
            <div class="acu-recipient-actions acu-recipient-actions-inline" aria-label="Assign recipient category">
              ${['to', 'cc', 'bcc']
                .map(
                  (mode) => `
                    <button
                      class="acu-mode-btn acu-mode-btn-inline acu-mode-btn-${mode} ${recipient.mode === mode ? 'active' : ''}"
                      type="button"
                      data-recipient-mode="${mode}"
                      data-recipient-id="${recipient.id}"
                      aria-pressed="${recipient.mode === mode}"
                    >
                      ${getRecipientModeLabel(mode)}
                    </button>
                  `
                )
                .join('')}
            </div>
            <div class="acu-recipient-copy">
              <div class="acu-recipient-name">${recipient.name} <span class="acu-recipient-inline-meta">${recipient.team}</span></div>
              <div class="acu-recipient-meta">${recipient.knoxId} &lt; ${recipient.email} &gt;</div>
            </div>
          </div>
          <button class="acu-recipient-remove" type="button" data-remove-recipient="${recipient.id}" aria-label="Remove ${recipient.name}" ${assigned ? '' : 'disabled'}>
            <i class="bi bi-x-lg"></i>
          </button>
        </article>
      `;
    })
    .join('')
    : '<div class="acu-recipient-empty">Recipient list is blank. Search by Knox ID and click a result to add members.</div>';
}

function renderMembersModal() {
  renderRecipientCounters();
  renderRecipientAutocomplete();
  renderRecipientList();
}

function openMembersModal(groupId) {
  alertCommunicationState.activeGroupId = groupId;
  const group = getGroupById(groupId);
  syncRecipientsFromGroup(groupId);
  clearRecipientSelection();
  dom.membersModalGroupMeta.textContent = `${group.id} · ${group.name} · ${group.category} / ${group.subCategory}`;
  dom.recipientSearch.value = '';
  renderMembersModal();
  membersModalInstance.show();
}

function renderAlertModes(groupId) {
  const group = getGroupById(groupId);
  dom.alertModeMeta.textContent = `${group.id} · ${group.name}`;
  dom.alertModeList.innerHTML = group.modes
    .map(
      (mode) => `
        <div class="acu-mode-item">
          <div>
            <h3>${mode.label}</h3>
            <p>${mode.description}</p>
          </div>
          <label class="acu-switch" aria-label="Toggle ${mode.label}">
            <input type="checkbox" ${mode.active ? 'checked' : ''} data-mode-key="${mode.key}" data-group-mode="${group.id}" />
            <span class="acu-switch-slider"></span>
          </label>
        </div>
      `
    )
    .join('');
}

function openAlertModeDrawer(groupId) {
  alertCommunicationState.activeGroupId = groupId;
  renderAlertModes(groupId);
  alertModeDrawerInstance.show();
}

function showToast(message) {
  clearTimeout(toastTimer);

  let toast = document.querySelector('.custom-ui-wrapper .acu-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'acu-toast';
    document.querySelector('.custom-ui-wrapper').appendChild(toast);
  }

  toast.textContent = message;
  requestAnimationFrame(() => toast.classList.add('show'));
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2400);
}

function bindGroupInteractions() {
  dom.groupList.querySelectorAll('[data-open-members]').forEach((button) => {
    button.addEventListener('click', () => openMembersModal(button.dataset.openMembers));
  });

  dom.groupList.querySelectorAll('[data-open-alert-mode]').forEach((button) => {
    button.addEventListener('click', () => openAlertModeDrawer(button.dataset.openAlertMode));
  });

  dom.groupList.querySelectorAll('.collapse').forEach((collapseElement) => {
    collapseElement.addEventListener('show.bs.collapse', () => {
      const icon = collapseElement.parentElement.querySelector('.acu-collapse-btn i');
      if (icon) icon.className = 'bi bi-chevron-up';
    });
    collapseElement.addEventListener('hide.bs.collapse', () => {
      const icon = collapseElement.parentElement.querySelector('.acu-collapse-btn i');
      if (icon) icon.className = 'bi bi-chevron-down';
    });
  });

  dom.groupList.querySelectorAll('[data-channel]').forEach((checkbox) => {
    checkbox.addEventListener('change', () => {
      const group = getGroupById(checkbox.dataset.groupId);
      const member = group.members.find((item) => item.id === checkbox.dataset.memberId);
      member.channels[checkbox.dataset.channel] = checkbox.checked;
      showToast(`${member.name} updated for ${checkbox.dataset.channel}.`);
    });
  });

  dom.groupList.querySelectorAll('[data-delete-member]').forEach((button) => {
    button.addEventListener('click', () => {
      const [groupId, memberId] = button.dataset.deleteMember.split(':');
      const group = getGroupById(groupId);
      group.members = group.members.filter((member) => member.id !== memberId);
      renderGroups();
      showToast('Member removed from the group.');
    });
  });
}

function bindStaticEvents() {
  [dom.groupStatus].forEach((element) => {
    element.addEventListener('change', renderGroups);
  });

  dom.searchGroup.addEventListener('input', renderGroups);
  dom.searchAction.addEventListener('click', renderGroups);
  dom.newGroupAction.addEventListener('click', () => showToast('New group flow can be connected to your backend endpoint.'));

  document.querySelectorAll('[data-sort]').forEach((button) => {
    button.addEventListener('click', () => {
      alertCommunicationState.sort = button.dataset.sort;
      document.querySelectorAll('[data-sort]').forEach((item) => item.classList.remove('active'));
      button.classList.add('active');
      renderGroups();
    });
  });

  document.querySelectorAll('[data-bulk-mode]').forEach((button) => {
    button.addEventListener('click', () => {
      alertCommunicationState.bulkMode = button.dataset.bulkMode;
      assignModeToRecipients(getBulkTargetRecipientIds(), alertCommunicationState.bulkMode);
      document.querySelectorAll('[data-bulk-mode]').forEach((item) => item.classList.remove('active'));
      button.classList.add('active');
      renderMembersModal();
    });
  });

  document.querySelectorAll('[data-move-action]').forEach((button) => {
    button.addEventListener('click', () => {
      moveSelectedRecipients(button.dataset.moveAction);
      renderMembersModal();
    });
  });

  dom.recipientSearch.addEventListener('input', renderMembersModal);
  dom.clearRecipientSearch.addEventListener('click', () => {
    dom.recipientSearch.value = '';
    renderMembersModal();
    dom.recipientSearch.focus();
  });

  dom.recipientAutocomplete.addEventListener('click', (event) => {
    const option = event.target.closest('[data-add-recipient]');
    if (!option) return;

    const recipient = alertCommunicationState.recipientDirectory.find((item) => item.id === option.dataset.addRecipient);
    if (!recipient) return;

    if (recipient.mode) {
      showToast('Already added');
      dom.recipientSearch.select();
      return;
    }

    recipient.mode = 'to';
    if (!isRecipientRowSelected(recipient.id)) {
      alertCommunicationState.selectedRecipientIds = [...alertCommunicationState.selectedRecipientIds, recipient.id];
    }
    activeRecipientChipId = recipient.id;
    dom.recipientSearch.value = '';
    renderMembersModal();
  });

  dom.recipientSearch.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter') return;
    const firstOption = dom.recipientAutocomplete.querySelector('[data-add-recipient]');
    if (!firstOption) return;
    event.preventDefault();
    firstOption.click();
  });

  dom.recipientList.addEventListener('click', (event) => {
    const removeButton = event.target.closest('[data-remove-recipient]');
    const button = event.target.closest('[data-recipient-id][data-recipient-mode]');
    const card = event.target.closest('.acu-recipient-item');

    if (removeButton) {
      const recipient = alertCommunicationState.recipientDirectory.find((item) => item.id === removeButton.dataset.removeRecipient);
      if (!recipient) return;
      recipient.mode = null;
      alertCommunicationState.selectedRecipientIds = alertCommunicationState.selectedRecipientIds.filter((id) => id !== recipient.id);
      if (activeRecipientChipId === recipient.id) activeRecipientChipId = null;
      renderMembersModal();
      return;
    }

    if (button) {
      const recipient = alertCommunicationState.recipientDirectory.find((item) => item.id === button.dataset.recipientId);
      recipient.mode = button.dataset.recipientMode;
      if (!isRecipientRowSelected(recipient.id)) {
        alertCommunicationState.selectedRecipientIds = [...alertCommunicationState.selectedRecipientIds, recipient.id];
      }
      activeRecipientChipId = recipient.id;
      renderMembersModal();
      return;
    }

    if (!card) return;

    toggleRecipientSelection(card.dataset.recipientId);
    renderMembersModal();
  });

  dom.recipientList.addEventListener('keydown', (event) => {
    const card = event.target.closest('.acu-recipient-item');
    const interactiveControl = event.target.closest('button, input, a, select, textarea');
    if (interactiveControl && interactiveControl !== card) return;
    if (!card || !['Enter', ' '].includes(event.key)) return;
    event.preventDefault();
    toggleRecipientSelection(card.dataset.recipientId);
    renderMembersModal();
  });

  document.addEventListener('click', (event) => {
    const insideSearch = event.target.closest('.acu-recipient-search-wrap');
    if (!insideSearch) {
      dom.recipientAutocomplete.classList.add('d-none');
    }
  });

  dom.saveMembersAction.addEventListener('click', () => {
    const group = getGroupById(alertCommunicationState.activeGroupId);
    const selectedRecipients = getSortedRecipients(alertCommunicationState.recipientDirectory).filter((recipient) => recipient.mode);
    group.members = selectedRecipients.map((recipient, index) => {
      const existing = group.members.find((member) => member.email === recipient.email) || {};
      return {
        id: recipient.id,
        name: recipient.name,
        email: recipient.email,
        phone: existing.phone || `98${String(index).padStart(8, '0')}`,
        team: recipient.team,
        mailStatus: recipient.mode.toUpperCase(),
        channels: existing.channels || {
          knoxMail: true,
          knoxAnnouncement: recipient.mode !== 'bcc',
          knoxMessenger: true,
          whatsapp: recipient.mode === 'to',
          sms: recipient.mode !== 'cc'
        }
      };
    });
    membersModalInstance.hide();
    renderGroups();
    showToast('Recipients were added to the alert group.');
  });

  dom.alertModeList.addEventListener('change', (event) => {
    const checkbox = event.target.closest('[data-mode-key]');
    if (!checkbox) return;
    const group = getGroupById(checkbox.dataset.groupMode);
    const mode = group.modes.find((item) => item.key === checkbox.dataset.modeKey);
    mode.active = checkbox.checked;
    renderGroups();
  });
}

function initDom() {
  dom.groupStatus = document.getElementById('groupStatus');
  dom.searchGroup = document.getElementById('searchGroup');
  dom.searchAction = document.getElementById('searchAction');
  dom.newGroupAction = document.getElementById('newGroupAction');
  dom.groupList = document.getElementById('groupList');
  dom.emptyState = document.getElementById('emptyState');
  dom.membersModalGroupMeta = document.getElementById('membersModalGroupMeta');
  dom.recipientCounters = document.getElementById('recipientCounters');
  dom.recipientSearch = document.getElementById('recipientSearch');
  dom.recipientAutocomplete = document.getElementById('recipientAutocomplete');
  dom.clearRecipientSearch = document.getElementById('clearRecipientSearch');
  dom.recipientList = document.getElementById('recipientList');
  dom.saveMembersAction = document.getElementById('saveMembersAction');
  dom.alertModeMeta = document.getElementById('alertModeMeta');
  dom.alertModeList = document.getElementById('alertModeList');

  membersModalInstance = new bootstrap.Modal(document.getElementById('membersModal'));
  alertModeDrawerInstance = new bootstrap.Offcanvas(document.getElementById('alertModeDrawer'));
}

document.addEventListener('DOMContentLoaded', () => {
  initializeRecipientSortOrder();
  initDom();
  bindOverlayViewportBehavior();
  bindStaticEvents();
  renderGroups();
  renderMembersModal();
});
