# Alert Communication UI Execution Plan

## 1. Folder setup

```text
.
├── index.html
├── assets
│   ├── css
│   │   └── alert-communication.css
│   ├── js
│   │   └── alert-communication.js
│   └── img
└── docs
    └── implementation-plan.md
```

## 2. Component breakdown

- `Alert Communication Page`
  - Breadcrumb + page title
  - Filter/search toolbar
  - Summary metrics strip
  - Responsive group accordion cards
  - Member table with channel toggles
- `Members / Recipients Modal`
  - Search input
  - Live counters for Total / To / CC / BCC
  - Recipient assignment list
  - Selected chip board grouped by To / CC / BCC
- `Alert Mode Drawer`
  - Delivery mode list
  - Toggle switches for each communication channel

## 3. Styling strategy

- Scope all custom styles under `.custom-ui-wrapper`
- Use Bootstrap 5 for layout, grid, modal, offcanvas, and utility support
- Use Bootstrap Icons for interaction affordances
- Apply a controlled token system using CSS variables for:
  - colors
  - shadows
  - spacing
  - borders
  - typography
- Use soft cards, elevated surfaces, and clear state colors for production-ready hierarchy
- Keep responsive behavior consistent across desktop, tablet, and mobile breakpoints

## 4. Interaction logic

- Render groups from dummy JSON data using vanilla JavaScript
- Filter groups by status, category, date, and keyword search
- Sort via dropdown actions
- Open the member modal from summary or table actions
- Assign recipients to `To`, `CC`, and `BCC`
- Update counters in real time
- Render selected recipients as categorized chips
- Show delete affordance on chip hover
- Persist visual state for selected chips and hover feedback
- Open alert mode drawer and update channel switches instantly
- Provide lightweight toast feedback for major actions

## 5. Final integration

- Load Bootstrap and Bootstrap Icons with CDN links in `index.html`
- Keep HTML, CSS, and JavaScript in separate files for maintainability
- Avoid editing any global project styles
- Use reusable rendering functions so data can be swapped with API responses later
- Keep markup semantic and accessible with labels, button states, and live updates
